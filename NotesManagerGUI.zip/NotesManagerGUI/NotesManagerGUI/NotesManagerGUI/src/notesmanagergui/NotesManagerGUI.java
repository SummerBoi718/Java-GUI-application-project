import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.Random;//for randomizing colors
import java.util.HashMap;//to hold the keys and the color value lol
//import javax.swing.filechooser.FileNameExtensionFilter;

public class NotesManagerGUI {
    private JFrame frame;
    private JPanel panel;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JButton registerButton;
    private JCheckBox ucheckbox;
    private String currentUser;
    public JLabel usernameLabel1;
    public JLabel passwordLabel1;
    public JLabel titleLabel1;
    public Color justineSkincolor=Color.BLACK;
    public Font Universalfont;
    

    // Constructor
    public NotesManagerGUI() {
    frame = new JFrame("Notes Manager");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setPreferredSize(new Dimension(400, 300)); // Set preferred size of the frame

    panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                // Draw background design
                drawLinedPaper(g);
            }

            private void drawLinedPaper(Graphics g) {
                // Draw gradient background
                Graphics2D g2d = (Graphics2D) g;
                Color color1 = new Color(255, 255, 255); // White
                Color color2 = new Color(240, 240, 240); // Light gray
                GradientPaint gradient = new GradientPaint(0, 0, color1, getWidth(), getHeight(), color2);
                g2d.setPaint(gradient);
                g2d.fillRect(0, 0, getWidth(), getHeight());

                // Draw lines
                g.setColor(Color.LIGHT_GRAY);
                int lineSpacing = 20; // Spacing between lines
                for (int y = 0; y < getHeight(); y += lineSpacing) {
                    g.drawLine(0, y, getWidth(), y);
                }
            }
            
        };
    panel.setLayout(null); // Increased rows to accommodate additional components

    // Custom font and font color for labels
    // Create and style label "Notes Manager"
    JLabel titleLabel = new JLabel("Notes Manager");
    titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
    titleLabel.setForeground(new Color(59, 89, 152)); // Facebook blue color
    titleLabel.setBounds(100, 20, 200, 30); // Position and size
    this.titleLabel1=titleLabel;
    Font labelFont = new Font("Arial", Font.BOLD, 13);
    Universalfont=labelFont;
    Color labelColor = justineSkincolor;

    JLabel usernameLabel = new JLabel("Username:");
    this.usernameLabel1=usernameLabel;
     usernameLabel.setBounds(50, 70, 80, 25);
    usernameLabel.setFont(labelFont);
    usernameLabel.setForeground(labelColor);

    usernameField = new JTextField();
    usernameField.setFont(labelFont); // Applying the same font to text fields
    usernameField.setBounds(150, 70, 165, 25);

    JLabel passwordLabel = new JLabel("Password:");
    passwordLabel.setBounds(50, 120, 80, 25);
    this.passwordLabel1=passwordLabel;
    passwordLabel.setFont(labelFont);
    passwordLabel.setForeground(labelColor);

    passwordField = new JPasswordField();
    passwordField.setFont(labelFont);
    passwordField.setBounds(150, 120, 165, 25);

    loginButton = new JButton("Login");
    loginButton.setBackground(new Color(59, 89, 152)); // Facebook blue color
    loginButton.setForeground(Color.WHITE); // White text color
    loginButton.setBounds(50, 170, 100, 25);
        loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                login();
            }
        });
    loginButton.setFont(labelFont);

    registerButton = new JButton("Register");
    registerButton.setBackground(new Color(0, 128, 0)); // Green color
    registerButton.setForeground(Color.WHITE); // White text color
    registerButton.setBounds(215, 170, 100, 25);
        registerButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                register();
            }
        });
    JCheckBox checkbox=new JCheckBox();
    checkbox.setBounds(120, 120, 25, 25);
    registerButton.setFont(labelFont);
    passwordField.setVisible(true);
    // Adding components to the panel
    panel.add(titleLabel);
    panel.add(usernameLabel);
    panel.add(usernameField);
    panel.add(passwordLabel);
    panel.add(passwordField);
    panel.add(checkbox);
    panel.add(loginButton);
    panel.add(registerButton);
    checkbox.addItemListener(new ItemListener() {
    public void itemStateChanged(ItemEvent e) {
        if(checkbox.isSelected()){
       
        passwordField.setEchoChar((char) 0);
        
        }else{
        passwordField.setEchoChar('$');
        }
        
    }
    });
    this.ucheckbox=checkbox; 
    // Setting custom background color for the panel
    

    frame.getContentPane().add(panel);
    frame.pack();
    frame.setLocationRelativeTo(null); // Center the frame on the screen
    frame.setVisible(true);
    }

    // Method to handle login process
    private void login() {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());
        
        // Authenticate user
        if (authenticate(username, password)) {
            currentUser = username;
            openMainMenu();
        } else {
            JOptionPane.showMessageDialog(frame, "Invalid username or password.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Method to handle user registration
    private void register() {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());
        
        // Validate username and password
        if (!isValidUsername(username)) {
            JOptionPane.showMessageDialog(frame, "Invalid username. Please enter alphanumeric characters only.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (!isValidPassword(password)) {
            JOptionPane.showMessageDialog(frame, "Invalid password. Please enter at least 6 characters.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Create new user account
        File accountFile = new File("accounts/" + username + ".txt");
        if (accountFile.exists()) {
            JOptionPane.showMessageDialog(frame, "Username already exists. Please choose a different username.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        try {
            FileWriter writer = new FileWriter(accountFile);
            writer.write(username + "\n" + password);
            writer.close();
            JOptionPane.showMessageDialog(frame, "Account created successfully.");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(frame, "Error creating account: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Method to authenticate user
    private boolean authenticate(String username, String password) {
        // Check if user's account file exists and contains correct credentials
        File accountFile = new File("accounts/" + username + ".txt");
        if (accountFile.exists()) {
            try {
                BufferedReader reader = new BufferedReader(new FileReader(accountFile));
                String storedUsername = reader.readLine();
                String storedPassword = reader.readLine();
                reader.close();
                return username.equals(storedUsername) && password.equals(storedPassword);
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(frame, "Error reading account file: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
        return false;
    }

    // Method to open main menu scene
    private void openMainMenu() {
        frame.getContentPane().removeAll();
        frame.repaint();

        panel = new JPanel();
        panel.setLayout(new GridLayout(4, 1));
        
        JButton viewNotesButton = new JButton("View your Notes");
        viewNotesButton.setFont(Universalfont);
        
        viewNotesButton.setBackground(new Color(85, 206, 255));
        viewNotesButton.setForeground(Color.white);
        viewNotesButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                viewNotes();
            }
        });

        JButton createNotesButton = new JButton("Write a Note");
        createNotesButton.setFont(Universalfont);
        createNotesButton.setBackground(new Color(127, 255, 0));
        createNotesButton.setForeground(Color.black);
        createNotesButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                createNote();
            }
        });
        // Add the "Back" button to return to login and register scene
        JButton backButton = new JButton("Back");
        backButton.setFont(Universalfont);
        backButton.setBackground(Color.RED);
        backButton.setForeground(Color.WHITE);
        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                displayLoginAndRegisterScene(); // Switch back to login and register scene
            }
        });
        JButton settingsButton = new JButton("Settings");
        settingsButton.setFont(Universalfont);
        settingsButton.setBackground(Color.GRAY);
        settingsButton.setForeground(Color.WHITE);
        settingsButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
               //settings scene
               settingsScene();
            }
        });
        
       //add the buttons in the panel to be visible
        panel.add(viewNotesButton);
        panel.add(createNotesButton);
        panel.add(backButton);
        panel.add(settingsButton);
        frame.getContentPane().add(panel);
        frame.pack();
    }
     // Method to display the login and register scene
    private void displayLoginAndRegisterScene() {
        frame.getContentPane().removeAll();
        frame.repaint();

        // Reinitialize the panel
        panel = new JPanel(){
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                // Draw background image
                 drawLinedPaper(g);
            }
                 private void drawLinedPaper(Graphics g) {
                // Draw gradient background
                Graphics2D g2d = (Graphics2D) g;
                Color color1 = new Color(255, 255, 255); // White
                Color color2 = new Color(240, 240, 240); // Light gray
                GradientPaint gradient = new GradientPaint(0, 0, color1, getWidth(), getHeight(), color2);
                g2d.setPaint(gradient);
                g2d.fillRect(0, 0, getWidth(), getHeight());

                // Draw lines
                g.setColor(Color.LIGHT_GRAY);
                int lineSpacing = 20; // Spacing between lines
                for (int y = 0; y < getHeight(); y += lineSpacing) {
                    g.drawLine(0, y, getWidth(), y);
                }
            }
               
            
        };
        panel.setLayout(null); // Set layout for login and register scene

        // Add components for login and register
        panel.add(titleLabel1);
        panel.add(usernameLabel1);
        panel.add(usernameField);
        panel.add(passwordLabel1);
        panel.add(passwordField);
        panel.add(loginButton);
        panel.add(registerButton);
        panel.add(ucheckbox);
        panel.setBackground(Color.GRAY);
        frame.getContentPane().add(panel);
        frame.pack();
    }
    //settings scene
    private void settingsScene(){
    frame.getContentPane().removeAll();
    frame.repaint();
    
    panel = new JPanel();
    panel.setLayout(new GridLayout(0, 1));
    panel.setBackground(Color.WHITE);
    JScrollPane scrollPane = new JScrollPane(panel); // Make the panel scrollable
    //functionalities to be added soon
    /*
     must be able to change the colors of various components
    change pass and username of the current logged in account
    change fonts of the texts dispalyed
    change text size and color
    reset to default settings
    

    */
    frame.getContentPane().add(scrollPane);
    frame.pack();
    }
    // Method to view notes
    private void viewNotes() {
    frame.getContentPane().removeAll();
    frame.repaint();

    panel = new JPanel();
    panel.setLayout(new GridLayout(0, 1)); // Use a GridLayout with variable rows
    Random ranNum=new Random();
    HashMap<Integer, Color>randomColors=new HashMap<Integer, Color>();
    randomColors.put(0, Color.green);
    //randomColors.put(1, Color.BLUE);
    randomColors.put(1, Color.YELLOW);
    randomColors.put(2, Color.MAGENTA);
    randomColors.put(3, Color.pink);
    // Load and display existing notes for the current user
    File userDir = new File("notes/" + currentUser);
    if (userDir.exists()) {
        File[] noteFiles = userDir.listFiles();
        if (noteFiles != null) {
            for (File noteFile : noteFiles) {
                String noteTitle = noteFile.getName().replace(".txt", ""); // Get note title without the file extension as it looks ugly asf
                JPanel panelcontainer=new JPanel();
                panelcontainer.setLayout(new FlowLayout(FlowLayout.CENTER));
                JButton viewButton = new JButton("View"); // Create "View" button
                viewButton.setBackground(Color.BLUE);
                viewButton.setForeground(Color.white);
                viewButton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        // View note contents when "View" button is clicked
                        viewNoteContents(noteFile);
                    }
                });
                JButton deleteButton = new JButton("Delete"); // Create "Delete" button
                deleteButton.setBackground(Color.ORANGE);
                deleteButton.setForeground(Color.WHITE);
                deleteButton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        // Delete the current note when pressed
                        if (noteFile.delete()) {
                            JOptionPane.showMessageDialog(frame, "Note deleted successfully.");
                            // After deleting, refresh the view so that deleted notes will disappear lol
                            viewNotes();
                        } else {
                            JOptionPane.showMessageDialog(frame, "Error deleting note.", "Error", JOptionPane.ERROR_MESSAGE);
                        }  
                    } 
                });
                JButton editButton=new JButton("Edit");
                editButton.setBackground(Color.WHITE);
                editButton.setForeground(Color.black);
                editButton.addActionListener(new ActionListener(){
                    public void actionPerformed(ActionEvent e){
                    //function to be implemented
                    //JOptionPane.showMessageDialog(frame, "Edit function to be implemented soon... on thursday or friday");
                    editNotes(noteFile);
                    }
                });
                int ran=ranNum.nextInt(4);
                panelcontainer.setBackground(randomColors.get(ran));
               
               
                JLabel titleLabels=new JLabel("Title : "+noteTitle);
                titleLabels.setFont(Universalfont);
                titleLabels.setForeground(Color.WHITE);
                 //set the foreground color of the title label if the bg is yellow so that the title will be visible
                if(panelcontainer.getBackground()==Color.YELLOW||panelcontainer.getBackground()==Color.green){
                titleLabels.setForeground(Color.black);
                }
                //panelcontainer.add(new JLabel("Title :"+noteTitle));
                panelcontainer.add(titleLabels);
                panelcontainer.add(viewButton);
                panelcontainer.add(deleteButton);
                panelcontainer.add(editButton);
                panel.add(panelcontainer);
                /*
                // Add note title and "View" button to the panel
                panel.add(new JLabel("Title :"+noteTitle));
                panel.add(viewButton);
                panel.add(deleteButton);*/
            }
        }
    }

    // Create the "Back" button
    JButton backButton = new JButton("Back");
    backButton.setBackground(Color.RED);
    backButton.setForeground(Color.WHITE);
    backButton.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            openMainMenu(); // Return to the main menu when "Back" button is clicked
        }
    });
    panel.add(backButton); // Add the "Back" button to the panel

    JScrollPane scrollPane = new JScrollPane(panel); // Make the panel scrollable
    frame.getContentPane().add(scrollPane);
    frame.pack();
    }  

    // Method to view note contents
    private void viewNoteContents(File noteFile) {
    try (BufferedReader reader = new BufferedReader(new FileReader(noteFile))) {
        StringBuilder contents = new StringBuilder();
        String line;
        // Read contents of the note file
        while ((line = reader.readLine()) != null) {
            contents.append(line).append("\n");
        }
        // Display note contents in a dialog
        JTextArea textArea = new JTextArea(contents.toString());
        textArea.setEditable(false); // Make the text area read-only
        JScrollPane scrollPane = new JScrollPane(textArea);
        JOptionPane.showMessageDialog(frame, scrollPane, "Note Contents", JOptionPane.PLAIN_MESSAGE);
    } catch (IOException ex) {
        JOptionPane.showMessageDialog(frame, "Error reading note contents: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
    }
    //method to edit notes
    private void editNotes(File noteFile){
    try{
        //add a panel
        FileReader file=new FileReader(noteFile);
        BufferedReader reader=new BufferedReader(file);
        StringBuilder contents=new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            contents.append(line).append("\n");
        }
        JTextArea textArea = new JTextArea(contents.toString());
        textArea.setEditable(true);
        JPanel panel=new JPanel();
        panel.setLayout(null);
        panel.add(textArea);
        JScrollPane scrollPane = new JScrollPane(textArea);
        //JOptionPane.showMessageDialog(frame, scrollPane, "Note Contents", JOptionPane.PLAIN_MESSAGE);
        int option = JOptionPane.showConfirmDialog(frame, scrollPane, "Edit Note", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            // if the user clicks ok in the dialog box the changes will eb saved on unto the text file
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(noteFile))) {
                writer.write(textArea.getText());
                JOptionPane.showMessageDialog(frame, "Changes Saved lol");
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(frame, "Error saving edited note: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }else{
              JOptionPane.showMessageDialog(frame, "Cancelled saving note");
        }
        reader.close();
    }catch(FileNotFoundException ex){
        JOptionPane.showMessageDialog(frame, "File not found :"+ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }catch (IOException ex) {
        JOptionPane.showMessageDialog(frame, "Error reading note contents: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
    }



    // Method to create a note scene
    private void createNote() {
    frame.getContentPane().removeAll();
    frame.repaint();

    panel = new JPanel();
    panel.setLayout(new BorderLayout());

    JTextField titleField = new JTextField();
    JTextArea contentArea = new JTextArea();
    contentArea.setRows(10); // Set rows for the content area
    contentArea.setColumns(40); // Set columns for the content area

    JButton saveButton = new JButton("Save Note");
    saveButton.setBackground(new Color(255, 215, 0));// yelats gold color ba
    saveButton.setForeground(Color.WHITE);
    saveButton.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            saveNoteAndReturn(titleField.getText(), contentArea.getText());
        }
    });

    JButton backButton = new JButton("Back");
    backButton.setBackground(Color.RED);
    backButton.setForeground(Color.WHITE);
    backButton.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            openMainMenu();
        }
    });

    // Panel for buttons
    JPanel buttonPanel = new JPanel();
    buttonPanel.setLayout(new FlowLayout(FlowLayout.RIGHT)); // Align buttons to the right
    buttonPanel.add(backButton);
    buttonPanel.add(saveButton);

    panel.add(new JLabel("Title:"), BorderLayout.NORTH);
    panel.add(titleField, BorderLayout.NORTH);
    panel.add(new JLabel("Content:"), BorderLayout.CENTER);
    panel.add(new JScrollPane(contentArea), BorderLayout.CENTER);
    panel.add(buttonPanel, BorderLayout.SOUTH); // Add button panel to the SOUTH position

    frame.getContentPane().add(panel);
    frame.pack();
   }


    // Method to load notes
    private String loadNotes() {
        StringBuilder notes = new StringBuilder();
        File userDir = new File("notes/" + currentUser);
        if (userDir.exists()) {
            File[] noteFiles = userDir.listFiles();
            if (noteFiles != null) {
                for (File noteFile : noteFiles) {
                    try {
                        BufferedReader reader = new BufferedReader(new FileReader(noteFile));
                        String line;
                        while ((line = reader.readLine()) != null) {
                          
                            notes.append(line).append("\n");
                        }
                        reader.close();
                    } catch (IOException ex) {
                        JOptionPane.showMessageDialog(frame, "Error reading note file: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        }
        return notes.toString();
    }

    // Method to save a note and return to the main menu
    private void saveNoteAndReturn(String title, String content) {
        // Validate title
        if (title.trim().isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Title cannot be empty.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Create directory for user's notes if it doesn't exist
        File userDir = new File("notes/" + currentUser);
        if (!userDir.exists()) {
            userDir.mkdirs();
        }

        // Create the note file
        File noteFile = new File(userDir, title + ".txt");
        try {
            FileWriter writer = new FileWriter(noteFile);
            writer.write("Title: "+title+"\n");         
            writer.write(content);
            writer.close();
            JOptionPane.showMessageDialog(frame, "Note created successfully.");
            openMainMenu(); // Return to the main menu after saving the note
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(frame, "Error creating note: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Method to validate username
    private boolean isValidUsername(String username) {
        // Check if username contains only alphanumeric characters
        //utilizes the String method matches which uses a regex as the paramtr
        //the argument usrname may start with any casing of the alphabet and and any number too and must o
        return username.matches("[a-zA-Z0-9]+");
    }

    // Method to validate password
    private boolean isValidPassword(String password) {
        // Check if password has at least 6 characters
        //this does not utilized any regex but may implement one in the future
        return password.length() >= 6;
    }

    // Main method
    public static void main(String[] args) {
        // Create directories for accounts and notes if they don't exist
        File accountsDir = new File("accounts");
        if (!accountsDir.exists()) {
            boolean created = accountsDir.mkdir();
            if (!created) {
                System.out.println("Failed to create accounts directory.");
                return;
            }
        }

        File notesDir = new File("notes");
        if (!notesDir.exists()) {
            boolean created = notesDir.mkdir();
            if (!created) {
                System.out.println("Failed to create notes directory.");
                return;
            }
        }

        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new NotesManagerGUI();
            }
        });
    }
}